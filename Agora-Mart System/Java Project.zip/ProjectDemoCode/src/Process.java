

public abstract class Process {
	
	public abstract double price();

}

//Convert this class into interface to demonstrate abstraction