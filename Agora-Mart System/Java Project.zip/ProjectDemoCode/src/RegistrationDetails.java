

public class RegistrationDetails {
	static String username ;
	static String password;
}
//add email 